"""IIMT CI-05 control/planning without ROS. All network I/O starts at connect()."""


# start delvewheel patch
def _delvewheel_patch_1_13_2():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'iimt_native.libs'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_13_2()
del _delvewheel_patch_1_13_2
# end delvewheel patch

from .config import JOINTS, Arm, Scene
from .models import ci05_scene
from .robot import Execution, Robot
from .trajectory import Trajectory

__all__ = ["Arm", "Scene", "JOINTS", "ci05_scene", "Robot", "Execution", "Trajectory"]
__version__ = "0.1.0"
